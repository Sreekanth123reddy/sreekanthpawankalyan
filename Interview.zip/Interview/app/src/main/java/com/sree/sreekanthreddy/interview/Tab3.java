package com.sree.sreekanthreddy.interview;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;


public class Tab3 extends Fragment {
    ListView mylistview;
    String url;
    int[] images = {R.drawable.antonym, R.drawable.comprehension, R.drawable.orderingwords, R.drawable.selectword, R.drawable.spottheerror, R.drawable.synonyms, R.drawable.verbalanalogies};
    String[] Names = { "Antonyms", "Comprehension", "Ordering Words", "Select Word", "Spot The Error", "Synonyms", "Verbal Analogies"};
    private static final String TAG = "Tab1Fragment";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tab1, container, false);
        super.onCreate(savedInstanceState);
        mylistview = (ListView) view.findViewById(R.id.listview);
        Tab3.CustomAdapter customAdapter = new Tab3.CustomAdapter();
        mylistview.setAdapter(customAdapter);
        mylistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","antonym");
                    bundle.putString("domain","antonyms");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 1) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","comprehension");
                    bundle.putString("domain","comprehensions");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 2) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","ordering");
                    bundle.putString("domain","orderings");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 3) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","select");
                    bundle.putString("domain","selects");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 4) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","spot");
                    bundle.putString("domain","spots");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 5) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","synonym");
                    bundle.putString("domain","synonyms");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 6) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","verbal");
                    bundle.putString("domain","verbals");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
            }
        });
        return view;
    }
    class CustomAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return images.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = getLayoutInflater().inflate(R.layout.customlayout1, null);
            ImageView myImageView = (ImageView) view.findViewById(R.id.imageView);
            TextView myTextView = (TextView) view.findViewById(R.id.textview);
            myImageView.setImageResource(images[position]);
            myTextView.setText(Names[position]);
            return view;
        }
    }

}