package com.sree.sreekanthreddy.interview;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class Webactivity extends AppCompatActivity {
    WebView webView;
    String url;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webactivity);
        webView = (WebView) findViewById(R.id.webview);

        progressDialog = ProgressDialog.show(Webactivity.this, "", "Loading...");

        WebSettings webSettings = webView.getSettings();
        webView.setWebViewClient(new myWebClient());
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        webSettings.setJavaScriptEnabled(true);
        Bundle bundle = new Bundle();
        Intent in = getIntent();
        bundle = in.getBundleExtra("bundle");
        int position = bundle.getInt("position");
        String name = bundle.getString("name");
        String domain = bundle.getString("domain");

        if (domain.equals("ages")) {
            if (name.equals("age")) {

                url = "file:///android_asset/ages.html";
            }
        }
        if (domain.equals("areas")) {
            if (name.equals("area")) {

                url = "https://www.careerbless.com/aptitude/qa/area.php";
            }
        }
        if (domain.equals("averages")) {
            if (name.equals("average")) {

                url = "https://www.indiabix.com/aptitude/average/";
            }
        }
        if (domain.equals("calendars")) {
            if (name.equals("calendar")) {

                url = "https://www.indiabix.com/aptitude/calendar/";
            }
        }
        if (domain.equals("hcfs")) {
            if (name.equals("hcf")) {

                url = "https://www.indiabix.com/aptitude/problems-on-hcf-and-lcm/";
            }
        }
        if (domain.equals("boat")) {
            if (name.equals("boats")) {

                url = "https://www.indiabix.com/aptitude/boats-and-streams/";
            }
        }
        if (domain.equals("heights")) {
            if (name.equals("height")) {

                url = "https://www.indiabix.com/aptitude/height-and-distance/";
            }
        }
        if (domain.equals("mixtures")) {
            if (name.equals("mixture")) {

                url = "https://www.indiabix.com/aptitude/alligation-or-mixture/";
            }
        }
        if (domain.equals("numbers")) {
            if (name.equals("number")) {

                url = "https://www.indiabix.com/aptitude/numbers/";
            }
        }
        if (domain.equals("percentages")) {
            if (name.equals("percentage")) {

                url = "https://www.indiabix.com/aptitude/percentage/";
            }
        }
        if (domain.equals("probabilitys")) {
            if (name.equals("probability")) {

                url = "https://www.indiabix.com/aptitude/probability/";
            }
        }
        if (domain.equals("profits")) {
            if (name.equals("profit")) {

                url = "https://www.indiabix.com/aptitude/profit-and-loss/";
            }
        }
        if (domain.equals("ratios")) {
            if (name.equals("ratio")) {

                url = "https://www.indiabix.com/aptitude/ratio-and-proportion/";
            }
        }
        if (domain.equals("sis")) {
            if (name.equals("si")) {

                url = "https://www.indiabix.com/aptitude/simple-interest/";
            }
        }
        if (domain.equals("times")) {
            if (name.equals("time")) {

                url = "https://www.indiabix.com/aptitude/time-and-distance/";
            }
        }
        if (domain.equals("trains")) {
            if (name.equals("train")) {

                url = "https://www.indiabix.com/aptitude/problems-on-trains/";
            }
        }
        if (domain.equals("analogies")) {
            if (name.equals("analogie")) {

                url = "https://www.indiabix.com/verbal-ability/verbal-analogies/";
            }
        }
        if (domain.equals("assumptions")) {
            if (name.equals("assumption")) {

                url = "https://www.indiabix.com/verbal-reasoning/data-sufficiency/";
            }
        }
        if (domain.equals("bloods")) {
            if (name.equals("blood")) {

                url = "https://www.indiabix.com/verbal-reasoning/blood-relation-test/";
            }
        }
        if (domain.equals("decisions")) {
            if (name.equals("decision")) {

                url = "https://www.indiabix.com/verbal-ability/sentence-improvement/";
            }
        }
        if (domain.equals("directions")) {
            if (name.equals("direction")) {

                url = "https://www.indiabix.com/verbal-reasoning/direction-sense-test/";
            }
        }
        if (domain.equals("logicals")) {
            if (name.equals("logical")) {

                url = "https://www.indiabix.com/verbal-reasoning/logical-sequence-of-words/";
            }
        }
        if (domain.equals("deductions")) {
            if (name.equals("deduction")) {

                url = "https://www.indiabix.com/verbal-reasoning/classification/";
            }
        }
        if (domain.equals("symbols")) {
            if (name.equals("symbol")) {

                url = "https://www.indiabix.com/verbal-reasoning/series-completion/";
            }
        }
        if (domain.equals("antonyms")) {
            if (name.equals("antonym")) {

                url = "https://www.indiabix.com/verbal-ability/antonyms/";
            }
        }
        if (domain.equals("orderings")) {
            if (name.equals("ordering")) {

                url = "https://www.indiabix.com/verbal-ability/ordering-of-words/";
            }
        }
        if (domain.equals("selects")) {
            if (name.equals("select")) {

                url = "https://www.indiabix.com/verbal-ability/selecting-words/";
            }
        }
        if (domain.equals("spots")) {
            if (name.equals("spot")) {

                url = "https://www.indiabix.com/verbal-ability/spotting-errors/";
            }
        }
        if (domain.equals("synonyms")) {
            if (name.equals("synonym")) {

                url = "https://www.indiabix.com/verbal-ability/synonyms/";
            }
        }
        if (domain.equals("verbal")) {
            if (name.equals("verbals")) {

                url = "https://www.indiabix.com/verbal-ability/idioms-and-phrases/";
            }
        }
        if (domain.equals("hrs")) {
            if (name.equals("hr")) {

                url = "https://www.naukri.com/blog/frequently-asked-hr-interview-questions-and-answers/";
            }
        }
        if (domain.equals("softwares")) {
            if (name.equals("software")) {

                url = "https://content.wisestep.com/software-developer-interview-questions/";
            }
        }
        if (domain.equals("engineerings")) {
            if (name.equals("engineering")) {

                url = "https://www.careermatch.com/job-prep/interviews/10-essential-engineering-interview-questions-and-answers/";
            }
        }
        if (domain.equals("companys")) {
            if (name.equals("company")) {

                url = "https://www.geeksforgeeks.org/company-interview-corner/";
            }
        }
        if (domain.equals("ages1")) {
            if (name.equals("age1")) {

                url = "https://www.indiabix.com/aptitude/problems-on-ages/formulas";
            }
        }
        if (domain.equals("areas1")) {
            if (name.equals("area1")) {

                url = "https://www.indiabix.com/aptitude/area/formulas";
            }
        }
        if (domain.equals("averages1")) {
            if (name.equals("average1")) {

                url = "https://www.indiabix.com/aptitude/average/formulas";
            }
        }
        if (domain.equals("calenders1")) {
            if (name.equals("calender1")) {

                url = "https://www.indiabix.com/aptitude/calendar/formulas";
            }
        }
        if (domain.equals("hcfs1")) {
            if (name.equals("hcf1")) {

                url = "https://www.indiabix.com/aptitude/problems-on-hcf-and-lcm/formulas";
            }
        }
        if (domain.equals("boats1")) {
            if (name.equals("boat")) {

                url = "https://www.indiabix.com/aptitude/boats-and-streams/formulas";
            }
        }
        if (domain.equals("heights1")) {
            if (name.equals("height1")) {

                url = "https://www.indiabix.com/aptitude/height-and-distance/formulas";
            }
        }
        if (domain.equals("mixtures1")) {
            if (name.equals("mixture1")) {

                url = "https://www.indiabix.com/aptitude/alligation-or-mixture/formulas";
            }
        }
        if (domain.equals("numbers1")) {
            if (name.equals("number1")) {

                url = "file:///android_asset/area.html";
            }
        }
        if (domain.equals("percentages1")) {
            if (name.equals("percentage1")) {

                url = "https://www.indiabix.com/aptitude/percentage/formulas";
            }
        }
        if (domain.equals("permutations1")) {
            if (name.equals("permutation1")) {

                url = "https://www.indiabix.com/aptitude/permutation-and-combination/formulas";
            }
        }
        if (domain.equals("percentags11")) {
            if (name.equals("percentage11")) {

                url = "https://www.indiabix.com/aptitude/percentage/formulas";
            }
        }
        if (domain.equals("probabilitys1")) {
            if (name.equals("probability1")) {

                url = "https://www.indiabix.com/aptitude/probability/formulas";
            }
        }
        if (domain.equals("profits1")) {
            if (name.equals("profit1")) {

                url = "https://www.indiabix.com/aptitude/profit-and-loss/formulas";
            }
        }
        if (domain.equals("ratios1")) {
            if (name.equals("ratio1")) {

                url = "https://www.indiabix.com/aptitude/ratio-and-proportion/formulas";
            }
        }
        if (domain.equals("sis1")) {
            if (name.equals("si1")) {

                url = "https://www.indiabix.com/aptitude/simple-interest/formulas";
            }
        }
        if (domain.equals("times1")) {
            if (name.equals("time1")) {

                url = "https://www.indiabix.com/aptitude/time-and-work/formulas";
            }
        }
        if (domain.equals("trains1")) {
            if (name.equals("train")) {

                url = "https://www.indiabix.com/aptitude/problems-on-trains/formulas";
            }
        }
        if (domain.equals("tips")) {
            if (name.equals("tip")) {

                url = "https://www.topresume.com/career-advice/tips-for-getting-a-job-how-to-create-your-own-luck";
            }
        }
        webView.loadUrl(url);
    }
    public class myWebClient extends WebViewClient
    {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);


        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {

            view.loadUrl(url);
            return true;

        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            if (progressDialog.isShowing()) {
                progressDialog.dismiss();
            }


        }
    }







    @Override
    // This method is used to detect back button
    public void onBackPressed() {
        if(webView.canGoBack()) {
            webView.goBack();
        } else {
            // Let the system handle the back button
            super.onBackPressed();
        }
    }

}
