package com.sree.sreekanthreddy.interview;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;


public class Tab2 extends Fragment {
    ListView mylistview;
    String url;
    int[] images = {R.drawable.analogies, R.drawable.assumptions, R.drawable.blood, R.drawable.decisionmaking, R.drawable.directions, R.drawable.logical, R.drawable.logicaldeduction, R.drawable.symbol};
    String[] Names = {"Analogies", "Assumptions", "Problems on Blood Relationships", "Decision Making", "Directions", "Logical Problems", "Logical Deductions", "Symbol Series"};
    private static final String TAG = "Tab1Fragment";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tab1, container, false);
        super.onCreate(savedInstanceState);
        mylistview = (ListView) view.findViewById(R.id.listview);
        Tab2.CustomAdapter customAdapter = new Tab2.CustomAdapter();
        mylistview.setAdapter(customAdapter);
        mylistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","analogie");
                    bundle.putString("domain","analogies");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 1) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","assumption");
                    bundle.putString("domain","assumptions");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 2) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","blood");
                    bundle.putString("domain","bloods");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);;
                }
                if (position == 3) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","decision");
                    bundle.putString("domain","decisions");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 4) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","direction");
                    bundle.putString("domain","directions");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 5) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","logical");
                    bundle.putString("domain","logicals");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 6) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","deduction");
                    bundle.putString("domain","deductions");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 7) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","symbol");
                    bundle.putString("domain","symbols");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }

            }
        });
        return view;
    }
    class CustomAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return images.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = getLayoutInflater().inflate(R.layout.customlayout1, null);
            ImageView myImageView = (ImageView) view.findViewById(R.id.imageView);
            TextView myTextView = (TextView) view.findViewById(R.id.textview);
            myImageView.setImageResource(images[position]);
            myTextView.setText(Names[position]);
            return view;
        }
    }

}