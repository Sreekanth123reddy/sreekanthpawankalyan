package com.sree.sreekanthreddy.interview;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class Formula extends AppCompatActivity {
    ListView mylistview;

    int[] images = {R.drawable.ages, R.drawable.area, R.drawable.average, R.drawable.calender, R.drawable.hcflcm, R.drawable.boats, R.drawable.heights, R.drawable.mixtures, R.drawable.numbers, R.drawable.percentages, R.drawable.permutations, R.drawable.percentages, R.drawable.probability, R.drawable.profitandloss, R.drawable.ratios, R.drawable.simpleinterest, R.drawable.timeandwork, R.drawable.train};
    String[] Names = {"Ages", "Area", "Average", "Calender", "HCF & LCM", "Boats & Streams", "Heights", "Mixtures", "Numbers", "Percentages", "Permutations & Combinations", "Percentages", "Probability", "Profit & Loss", "Ratios & Proportions", "SI & CI", "Time & Work", "TrainProblems"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formula);
        mylistview = (ListView) findViewById(R.id.listview);
        CustomAdapter customAdapter = new CustomAdapter();
        mylistview.setAdapter(customAdapter);
        mylistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","age1");
                    bundle.putString("domain","ages1");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 1) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","area1");
                    bundle.putString("domain","areas1");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);

                }
                if (position == 2) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","average1");
                    bundle.putString("domain","averages1");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);

                }
                if (position == 3) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","calender1");
                    bundle.putString("domain","calenders1");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 4) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","hcf1");
                    bundle.putString("domain","hcfs1");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 5) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","boat1");
                    bundle.putString("domain","boats1");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 6) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","height1");
                    bundle.putString("domain","heights1");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 7) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","mixture1");
                    bundle.putString("domain","mixtures1");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 8) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","number1");
                    bundle.putString("domain","numbers1");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 9) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","percentage1");
                    bundle.putString("domain","percentages1");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 10) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","permutation1");
                    bundle.putString("domain","permutations1");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 11) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","percentage11");
                    bundle.putString("domain","percentages11");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 12) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","probability1");
                    bundle.putString("domain","probabilitys1");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 13) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","ratio1");
                    bundle.putString("domain","ratios1");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 14) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","si1");
                    bundle.putString("domain","sis1");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 15) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","time1");
                    bundle.putString("domain","times1");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 16) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","train1");
                    bundle.putString("domain","trains1");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
            }
        });
    }
    class CustomAdapter extends BaseAdapter implements com.sree.sreekanthreddy.interview.CustomAdapter {

        @Override
        public int getCount() {
            return images.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view=getLayoutInflater().inflate(R.layout.customlayout1,null);
            ImageView myImageView=(ImageView)view.findViewById(R.id.imageView);
            TextView myTextView=(TextView) view.findViewById(R.id.textview);
            myImageView.setImageResource(images[position]);
            myTextView.setText(Names[position]);
            return view;
        }
    }
}
