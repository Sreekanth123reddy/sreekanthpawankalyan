package com.sree.sreekanthreddy.interview;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;


public class Tab1 extends Fragment {
    ListView mylistview;
    String url;
    int[] images = {R.drawable.ages, R.drawable.area, R.drawable.average, R.drawable.calender, R.drawable.hcflcm, R.drawable.boats, R.drawable.heights, R.drawable.mixtures, R.drawable.numbers, R.drawable.percentages, R.drawable.permutations, R.drawable.percentages, R.drawable.probability, R.drawable.profitandloss, R.drawable.ratios, R.drawable.simpleinterest, R.drawable.timeandwork, R.drawable.train};
    String[] Names = {"Ages", "Area", "Average", "Calender", "HCF & LCM", "Boats & Streams", "Heights", "Mixtures", "Numbers", "Percentages", "Permutations & Combinations", "Percentages", "Probability", "Profit & Loss", "Ratios & Proportions", "SI & CI", "Time & Work", "TrainProblems"};
    private static final String TAG = "Tab1Fragment";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tab1, container, false);
        super.onCreate(savedInstanceState);
        mylistview = (ListView) view.findViewById(R.id.listview);
        Tab1.CustomAdapter customAdapter = new Tab1.CustomAdapter();
        mylistview.setAdapter(customAdapter);
        mylistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","age");
                    bundle.putString("domain","ages");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 1) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","area");
                    bundle.putString("domain","areas");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 2) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","average");
                    bundle.putString("domain","averages");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 3) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","calendar");
                    bundle.putString("domain","calendars");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 4) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","hcf");
                    bundle.putString("domain","hcfs");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 5) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","boat");
                    bundle.putString("domain","boats");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 6) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","height");
                    bundle.putString("domain","heights");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 7) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","mixture");
                    bundle.putString("domain","mixtures");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 8) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","number");
                    bundle.putString("domain","numbers");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 9) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","percentage");
                    bundle.putString("domain","percentages");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 10) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","permutation");
                    bundle.putString("domain","permutations");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 11) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","probability");
                    bundle.putString("domain","probabiltys");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 12) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","profit");
                    bundle.putString("domain","profits");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 13) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","ratio");
                    bundle.putString("domain","ratios");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 14) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","si");
                    bundle.putString("domain","sis");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 15) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","time");
                    bundle.putString("domain","times");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 16) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","train");
                    bundle.putString("domain","trains");
                    Intent in = new Intent(getContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
            }
        });
    return view;
    }
        class CustomAdapter extends BaseAdapter {

            @Override
            public int getCount() {
                return images.length;
            }

            @Override
            public Object getItem(int position) {
                return null;
            }

            @Override
            public long getItemId(int position) {
                return 0;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = getLayoutInflater().inflate(R.layout.customlayout1, null);
                ImageView myImageView = (ImageView) view.findViewById(R.id.imageView);
                TextView myTextView = (TextView) view.findViewById(R.id.textview);
                myImageView.setImageResource(images[position]);
                myTextView.setText(Names[position]);
                return view;
            }
        }

}