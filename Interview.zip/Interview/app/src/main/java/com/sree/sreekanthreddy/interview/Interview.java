package com.sree.sreekanthreddy.interview;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class Interview extends AppCompatActivity {
    int[] images={R.drawable.hr,R.drawable.software,R.drawable.engineering,R.drawable.companywise};
    String[] Names={"HR","Software Development","Engineering","Company-Wise"};
    ListView mylistview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interview);
        mylistview = (ListView) findViewById(R.id.listview);
        CustomAdapter customAdapter = new CustomAdapter();
        mylistview.setAdapter(customAdapter);
        mylistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","hr");
                    bundle.putString("domain","hrs");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 1) {

                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","software");
                    bundle.putString("domain","softwares");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 2) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","engineering");
                    bundle.putString("domain","engineerings");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }
                if (position == 3) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","company");
                    bundle.putString("domain","companys");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }


            }
        });
    }
    class CustomAdapter extends BaseAdapter implements com.sree.sreekanthreddy.interview.CustomAdapter {

        @Override
        public int getCount() {
            return images.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view=getLayoutInflater().inflate(R.layout.customlayout1,null);
            ImageView myImageView=(ImageView)view.findViewById(R.id.imageView);
            TextView myTextView=(TextView) view.findViewById(R.id.textview);
            myImageView.setImageResource(images[position]);
            myTextView.setText(Names[position]);
            return view;
        }
    }
}
