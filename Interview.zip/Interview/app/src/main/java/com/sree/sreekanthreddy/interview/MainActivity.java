package com.sree.sreekanthreddy.interview;

import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity<navigation> extends AppCompatActivity {
    private DrawerLayout mDrawerLayout;
    NavigationView navigationView;
    private ActionBarDrawerToggle mToggle;
    ListView mylistview;
    int[] images={R.drawable.aptitude,R.drawable.interview,R.drawable.quiz,R.drawable.formula,R.drawable.tips,};
    String[] Names={"Aptitude","Interview","Quiz","Formula","Tips and Tricks"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        mToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.open, R.string.close);
        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mylistview = (ListView) findViewById(R.id.listview);
        CustomAdapter customAdapter = new CustomAdapter();
        mylistview.setAdapter(customAdapter);
        navigationView=(NavigationView)findViewById(R.id.navigate);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                switch (item.getItemId()) {

                    case R.id.resumeupload:
                        Intent anIntent = new Intent(getApplicationContext(), ResumeActivity.class);
                        startActivity(anIntent);
                        mDrawerLayout.closeDrawers();
                        break;
                    case R.id.notifycations:
                         anIntent = new Intent(getApplicationContext(), JobActivity.class);
                        startActivity(anIntent);
                        mDrawerLayout.closeDrawers();
                        break;
                    case R.id.jobsearch:
                        anIntent=new Intent(getApplicationContext(),JobSearch.class);
                        startActivity(anIntent);
                        mDrawerLayout.closeDrawers();

                }
                return false;
            }
        });
        mylistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent myIntent = new Intent(view.getContext(), AptitudeActivity.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 1) {
                    Intent myIntent = new Intent(view.getContext(), Interview.class);
                    startActivityForResult(myIntent, 0);

                }
                if (position == 2) {
                    Intent myIntent = new Intent(view.getContext(), QuizActivity.class);
                    startActivityForResult(myIntent, 0);

                }
                if (position == 3) {
                    Intent myIntent = new Intent(view.getContext(), Formula.class);
                    startActivityForResult(myIntent, 0);

                }
                if (position == 4) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("position",position);
                    bundle.putString("name","tip");
                    bundle.putString("domain","tips");
                    Intent in = new Intent(getApplicationContext(), Webactivity.class);
                    in.putExtra("bundle",bundle);
                    startActivity(in);
                }

            }
        });
    }

    class CustomAdapter extends BaseAdapter implements com.sree.sreekanthreddy.interview.CustomAdapter {

    @Override
    public int getCount() {
        return images.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view=getLayoutInflater().inflate(R.layout.customlayout,null);
        ImageView myImageView=(ImageView)view.findViewById(R.id.imageView);
        TextView myTextView=(TextView) view.findViewById(R.id.textview);
        myImageView.setImageResource(images[position]);
        myTextView.setText(Names[position]);
        return view;
    }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(mToggle.onOptionsItemSelected(item))
        {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
