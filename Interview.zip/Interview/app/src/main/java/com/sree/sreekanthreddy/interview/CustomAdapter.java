package com.sree.sreekanthreddy.interview;

interface CustomAdapter {
}
