package com.sree.sreekanthreddy.ramcharan;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class OrangeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orange);
        ListView myListview =(ListView)findViewById(R.id.myListView);
        final ArrayList<String> myFamily = new ArrayList<String>();
        myFamily.add("Oola Oolala Ala");
        myFamily.add("Chilipiga");
        myFamily.add("Nenu Nuvvantu ");
        myFamily.add("Hello Ramantae");
        myFamily.add("O'Range");
        myFamily.add("Rooba Rooba");
        ArrayAdapter<String> arrayAdapter =new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,myFamily);
        myListview.setAdapter(arrayAdapter);
        myListview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Bundle bundle = new Bundle();
                bundle.putInt("position",i);
                bundle.putString("name","lyrics3");
                bundle.putString("domain","orange");
                Intent in = new Intent(getApplicationContext(), WebActivity.class);
                in.putExtra("bundle",bundle);
                startActivity(in);

            }
        });
        return;
    }
    }

