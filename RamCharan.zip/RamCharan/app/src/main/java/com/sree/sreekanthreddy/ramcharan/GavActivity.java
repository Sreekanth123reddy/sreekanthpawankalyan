package com.sree.sreekanthreddy.ramcharan;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class GavActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gav);
        ListView myListview =(ListView)findViewById(R.id.myListView);
        final ArrayList<String> myFamily = new ArrayList<String>();
        myFamily.add("Neeli Rangu Cheeralona");
        myFamily.add("Gulabi Kallu Rendu Mullu");
        myFamily.add("Ra Rakumara");
        myFamily.add("Pratichota naakae Swagatham");
        myFamily.add("Bavagari Choopae");
        myFamily.add("Kokkokkodi");
        ArrayAdapter<String> arrayAdapter =new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,myFamily);
        myListview.setAdapter(arrayAdapter);
        myListview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Bundle bundle = new Bundle();
                bundle.putInt("position",i);
                bundle.putString("name","lyrics7");
                bundle.putString("domain","gav");
                Intent in = new Intent(getApplicationContext(), WebActivity.class);
                in.putExtra("bundle",bundle);
                startActivity(in);

            }
        });
        return;
    }
}
