package com.sree.sreekanthreddy.ramcharan;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class WebActivity extends AppCompatActivity {
    WebView webView;
    String url;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);
        webView = (WebView) findViewById(R.id.webview);

        progressDialog = ProgressDialog.show(WebActivity.this, "", "Loading...");

        WebSettings webSettings = webView.getSettings();
        webView.setWebViewClient(new myWebClient());
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        webSettings.setJavaScriptEnabled(true);
        Bundle bundle = new Bundle();
        Intent in = getIntent();
        bundle = in.getBundleExtra("bundle");
        int position = bundle.getInt("position");
        String name = bundle.getString("name");
        String domain = bundle.getString("domain");

        if(domain.equals("chirutha")){
            if(name.equals("lyrics1")) {

                switch (position) {
                    case 0:
                        url = "file:///android_asset/yamahoyama.html";
                        break;
                    case 1:
                        url = "file:///android_asset/loveuraa.html";
                        break;
                    case 2:
                        url = "file:///android_asset/yenduko.html";
                        break;
                    case 3:
                        url = "file:///android_asset/chamak.html";
                        break;
                    case 4:
                        url = "file:///android_asset/maaro.html";
                        break;
                    case 5:
                        url = "file:///android_asset/ivvalae.html";
                        break;
                    case 6:
                        url = "file:///android_asset/innala.html";
                        break;                }


            }

    }

        if(domain.equals("magadheera")){
            if(name.equals("lyrics2")) {

                switch (position) {
                    case 0:
                        url = "file:///android_asset/bangaru.html";
                        break;
                    case 1:
                        url = "file:///android_asset/dheera.html";
                        break;
                    case 2:
                        url = "file:///android_asset/panchadara.html";
                        break;
                    case 3:
                        url = "file:///android_asset/jorsey.html";
                        break;
                    case 4:
                        url = "file:///android_asset/jorsey.html";
                        break;


                }


            }

        }
        if(domain.equals("orange")){
            if(name.equals("lyrics3")) {

                switch (position) {
                    case 0:
                        url = "file:///android_asset/oola.html";
                        break;
                    case 1:
                        url = "file:///android_asset/chilipiga.html";
                        break;
                    case 2:
                        url = "file:///android_asset/nenu.html";
                        break;
                    case 3:
                        url = "file:///android_asset/hello.html";
                        break;
                    case 4:
                        url = "file:///android_asset/orange.html";
                        break;
                    case 5:
                        url = "file:///android_asset/rooba.html";
                        break;

                }


            }

        }
        if(domain.equals("racha")){
            if(name.equals("lyrics4")) {

                switch (position) {
                    case 0:
                        url = "file:///android_asset/racha.html";
                        break;
                    case 1:
                        url = "file:///android_asset/vaana.html";
                        break;
                    case 2:
                        url = "file:///android_asset/dillaku.html";
                        break;
                    case 3:
                        url = "file:///android_asset/okapadam.html";
                        break;
                    case 4:
                        url = "file:///android_asset/okapadam.html";
                        break;

                }


            }

        }
        if(domain.equals("nayak")){
            if(name.equals("lyrics5")) {

                switch (position) {
                    case 0:
                        url = "file:///android_asset/laila.html";
                        break;
                    case 1:
                        url = "file:///android_asset/kathi.html";
                        break;
                    case 2:
                        url ="file:///android_asset/prema.html";
                        break;
                    case 3:
                        url = "file:///android_asset/oka.html";
                        break;
                    case 4:
                        url = "file:///android_asset/nellore.html";
                        break;
                    case 5:
                        url = "file:///android_asset/heynayak.html";
                        break;

                }


            }

        }
        if(domain.equals("yevadu")){
            if(name.equals("lyrics6")) {

                switch (position) {
                    case 0:
                        url = "file:///android_asset/freedom.html";
                        break;
                    case 1:
                        url = "file:///android_asset/neejataga.html";
                        break;
                    case 2:
                        url = "file:///android_asset/ayyo.html";
                        break;
                    case 3:
                        url = "file:///android_asset/cheliya.html";
                        break;
                    case 4:
                        url = "file:///android_asset/areyou.html";
                        break;
                    case 5:
                        url = "file:///android_asset/pimple.html";
                        break;

                }


            }

        }

     if(domain.equals("gav")){
        if(name.equals("lyrics7")) {

            switch (position) {
                case 0:
                    url = "file:///android_asset/neeli.html";
                    break;
                case 1:
                    url ="file:///android_asset/gulabi.html";
                    break;
                case 2:
                    url = "file:///android_asset/rara.html";
                    break;
                case 3:
                    url = "file:///android_asset/prathi.html";
                    break;
                case 4:
                    url = "file:///android_asset/bavagari.html";
                    break;
                case 5:
                    url = "file:///android_asset/kokodi.html";
                    break;

            }


        }

    }
        if(domain.equals("brucelee")){
            if(name.equals("lyrics8")) {

                switch (position) {
                    case 0:
                        url = "file:///android_asset/run.html";
                        break;
                    case 1:
                        url = "file:///android_asset/ria.html";
                        break;
                    case 2:
                        url = "file:///android_asset/kungfu.html";
                        break;
                    case 3:
                        url = "file:///android_asset/lechalo.html";
                        break;
                    case 4:
                        url = "file:///android_asset/alee.html";
                        break;

                }


            }

        }
        if(domain.equals("dhruva")){
            if(name.equals("lyrics9")) {

                switch (position) {
                    case 0:
                        url = "file:///android_asset/dhruva.html";
                        break;
                    case 1:
                        url = "file:///android_asset/choosa.html";
                        break;
                    case 2:
                        url = "file:///android_asset/pareshanu.html";
                        break;
                    case 3:
                        url = "file:///android_asset/neethone.html";
                        break;


                }


            }

        }
        if(domain.equals("rangastalam")){
            if(name.equals("lyrics10")) {

                switch (position) {
                    case 0:
                        url = "file:///android_asset/enta.html";
                        break;
                    case 1:
                        url = "file:///android_asset/ranga.html";
                        break;
                    case 2:
                        url = "file:///android_asset/rangamma.html";
                        break;
                    case 3:
                        url = "file:///android_asset/naganna.html";
                        break;
                    case 4:
                        url = "file:///android_asset/jigelrani.html";
                        break;
                    case 5:
                        url = "file:///android_asset/orayyo.html";
                        break;

                }


            }

        }
        webView.loadUrl(url);
}





                public class myWebClient extends WebViewClient
                 {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);


        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {

            view.loadUrl(url);
            return true;

        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            if (progressDialog.isShowing()) {
                progressDialog.dismiss();
            }


        }
    }







    @Override
    // This method is used to detect back button
    public void onBackPressed() {
        if(webView.canGoBack()) {
            webView.goBack();
        } else {
            // Let the system handle the back button
            super.onBackPressed();
        }
    }

}
