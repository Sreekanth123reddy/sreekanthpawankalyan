package com.sree.sreekanthreddy.ramcharan;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;


public class ChiruthaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chirutha);
        ListView myListview =(ListView)findViewById(R.id.myListView);
        final ArrayList<String> myFamily = new ArrayList<String>();
        myFamily.add("yamho yama");
        myFamily.add("love u raa");
        myFamily.add("yenduko ");
        myFamily.add("champak champak");
        myFamily.add("maaro maaro");
        myFamily.add("ivaalae");
        myFamily.add("innala bit");
        ArrayAdapter<String> arrayAdapter =new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,myFamily);
        myListview.setAdapter(arrayAdapter);
        myListview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Bundle bundle = new Bundle();
                bundle.putInt("position",i);
                bundle.putString("name","lyrics1");
                bundle.putString("domain","chirutha");
                Intent in = new Intent(getApplicationContext(), WebActivity.class);
                in.putExtra("bundle",bundle);
                startActivity(in);

            }
        });
return;
    }
}
