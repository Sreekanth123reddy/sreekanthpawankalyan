package com.sree.sreekanthreddy.ramcharan;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
public void chirutha(View view){
        Intent i =new Intent(MainActivity.this,ChiruthaActivity.class);
        startActivity(i);
}
    public void magadheera(View view){
        Intent i =new Intent(MainActivity.this,MagadheeraActivity.class);
        startActivity(i);
    }
    public void orange(View view){
        Intent i =new Intent(MainActivity.this,OrangeActivity.class);
        startActivity(i);
    }
    public void racha(View view){
        Intent i =new Intent(MainActivity.this,RachaActivity.class);
        startActivity(i);
    }
    public void nayak(View view){
        Intent i =new Intent(MainActivity.this,NayakActivity.class);
        startActivity(i);
    }
    public void yevadu(View view){
        Intent i =new Intent(MainActivity.this,YevaduActivity.class);
        startActivity(i);
    }
    public void gav(View view){
        Intent i =new Intent(MainActivity.this,GavActivity.class);
        startActivity(i);
    }
    public void brucelee(View view){
        Intent i =new Intent(MainActivity.this,BruceleeActivity.class);
        startActivity(i);
    }
    public void dhruva(View view){
        Intent i =new Intent(MainActivity.this,DhruvaActivity.class);
        startActivity(i);
    }
    public void rangastalam(View view){
        Intent i =new Intent(MainActivity.this,RangastalamActivity.class);
        startActivity(i);
    }


    @Override
    public void onBackPressed() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setMessage("Are you sure to exit?");
        builder.setCancelable(true);
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                dialog.cancel();
            }
        });
        builder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}


